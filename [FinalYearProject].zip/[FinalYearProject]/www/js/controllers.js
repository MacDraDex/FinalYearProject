angular.module('app.controllers', [])
  
.controller('loginCtrl', function($scope) {

})
   
.controller('menuCtrl', function($scope) {

})
   
.controller('addRecordCtrl', function($scope) {

})
   
.controller('displayRecordCtrl', function($scope) {

})
   
.controller('aboutCtrl', function($scope) {

})
   
.controller('searchCtrl', function($scope) {

})
   
.controller('deleteCtrl', function($scope) {

})
 